The default directory to place BIRT runtime image files.
